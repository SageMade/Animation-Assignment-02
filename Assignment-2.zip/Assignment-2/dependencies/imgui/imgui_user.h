#pragma once

#include "imgui_bezier.h"
#include "imgui_color.h"
#include "curve.hpp"