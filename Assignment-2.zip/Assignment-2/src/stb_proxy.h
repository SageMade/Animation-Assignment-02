#pragma once

#ifndef STB_PROXY
#define STB_PROXY
#endif